from django.http import JsonResponse

from .models import Blog, Comment


def list_blogs(request):
    # Get all of the blogs
    blogs = Blog.objects.all()

    # Turn the blogs into titles and urls
    response = []
    for blog in blogs:
        response.append({
            "title": blog.title,
            "href": blog.get_api_url()
        })

    # Return the blogs in a JsonResponse
    return JsonResponse({"blogs": response})


def show_blog_detail(request, id):
    # Get the blog
    blog = Blog.objects.get(id=id)

    # Return the blog and its comments in a dictionary
    comments = [
        {"id": c.id, "content": c.content}
        for c in blog.comments.all()
    ]
    response = {
        "title": blog.title,
        "content": blog.content,
        "comments": comments,
    }

    # Return the JsonResponse
    return JsonResponse(response)


def create_comment(request, blog_id):
    if request.method == "POST":
        blog = Blog.objects.get(id=blog_id)
        Comment.objects.create(
            content=request.POST.get("content"),
            blog=blog,
        )
        return JsonResponse({"message": "created"})
