# Conference GO

This is the instructor view of the student-facing app for Conference GO!

This repository has branches that track along with the projects performed
by the students.

| Branch name          | What's there                                            |
|----------------------|---------------------------------------------------------|
| main                 | The start of the project                                |
| 01-with-aggregates   | What happens after the lab _Aggregate Refactoring_      |
| 02-with-json-encoder | What happens after the lab _Building your JSON library_ |
| 03-restfulized       | What happens after _RESTfulize the app_                 |

Happy teaching!
