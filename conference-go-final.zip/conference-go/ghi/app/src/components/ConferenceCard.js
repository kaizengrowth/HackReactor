import {useState, useEffect} from 'react'

const ConferenceCard = (props) => {
    const [ conferenceDetails, setConferenceDetails] = useState({})
    const { conference } = props;
  
    useEffect(()=>{
      const loadConferenceDetails = async () => {
        const url = `http://localhost:8000/api/conferences/${conference.id}`
  
        const response = await fetch(url)
        if (response.ok) {
          const data = await response.json()
          setConferenceDetails(data.conference)
        }
      }
      
      loadConferenceDetails()
    }, [])
  
    
    if (Object.keys(conferenceDetails).length === 0) {
      return (
        <div className="card mb-3 shadow">
          <div className="card-body">
            <h5 className="card-title">Loading</h5>
          </div>
        </div>
      )
    }
  
    return (
      <div className="card mb-3 shadow" style={{"width":"25%"}}>
  
        <img src={conferenceDetails.location.picture_url} className="card-img-top" style={{"height":"50%"}}/>
  
        <div className="card-body">
          <h5 className="card-title">{conferenceDetails.name}</h5>
          <h6 className="card-subtitle mb-2 text-muted">
            {conferenceDetails.location.name}
          </h6>
          <p className="card-text">
            {conferenceDetails.description}
          </p>
        </div>
  
        <div className="card-footer">
          {new Date(conferenceDetails.starts).toLocaleDateString()}-{new Date(conferenceDetails.ends).toLocaleDateString()}
        </div>
      </div>
    );
  }

  export default ConferenceCard;