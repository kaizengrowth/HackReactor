import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const LocationList = () => {
  const [ locations, setLocations ] = useState([])

  useEffect(()=> {
    const loadData = async () => {
      const url = 'http://localhost:8000/api/locations/';
      const response = await fetch(url);

      if (response.ok) {
        const data = await response.json();
        setLocations(data.locations);
      } else {
        console.log("Error");
      }
    }

    loadData()
    
  }, [])

  return (
    <div className="row">
      <div className="offset-3 col-6">
        <div className="shadow p-4 mt-4">
          <h1>Locations</h1>
          <table className="table">
            <thead>
                <th>id</th>
                <th>name</th>
            </thead>
            <tbody>
                {
                    locations.map(l => <tr  key={l.id}>
                        <td>{l.id}</td><td>{l.name}</td>
                    </tr>)
                }
            </tbody>
          </table>
          <Link  to="/locations/new"><button className="btn btn-primary">Create New Location</button></Link>
        </div>
      </div>
    </div>
  );
}

export default LocationList;