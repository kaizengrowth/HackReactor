import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const ConferenceList = () => {
  const [ conferences, setConferences ] = useState([])

  useEffect(()=> {
    const loadData = async () => {
      const url = 'http://localhost:8000/api/conferences/';
      const response = await fetch(url);

      if (response.ok) {
        const data = await response.json();
        setConferences(data.conferences);
      } else {
        console.log("Error");
      }
    }

    loadData()
    
  }, [])

  return (
    <div className="row">
      <div className="offset-3 col-6">
        <div className="shadow p-4 mt-4">
          <h1>Conference</h1>
          <table className="table">
            <thead>
                <th>id</th>
                <th>name</th>
            </thead>
            <tbody>
                {
                  conferences.map(c => <tr key={c.id}>
                      <td>{c.id}</td><td>{c.name}</td>
                  </tr>)
                }
            </tbody>
          </table>
          <Link  to="/conferences/new"><button className="btn btn-primary">Create New Conference</button></Link>
        </div>
      </div>
    </div>
  );
}

export default ConferenceList;