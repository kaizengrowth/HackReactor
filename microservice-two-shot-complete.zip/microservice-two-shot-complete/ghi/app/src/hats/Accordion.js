import AccordionItem from './AccordionItem';
import { useState, useEffect } from 'react';

import React from 'react'

export default function Accordion() {
    const [hats, setHats] = useState([]);
    const [refresh, setRefresh] = useState(1);

    useEffect(() => {
        console.log("refreshed!");
        fetch("http://localhost:8090/api/hats/")
            .then(res => res.json())
            .then(res => res)
            .then(data => setHats(data.hats))
    }, [refresh])


    return (
        <div id="accordion">
            {hats.map(hat => <AccordionItem key={hat.id} data={hat} refresh={refresh} setRefresh={setRefresh} />)}
        </div>
    )
}