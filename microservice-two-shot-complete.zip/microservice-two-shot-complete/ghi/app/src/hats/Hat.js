import { Link } from 'react-router-dom';

const Hat = (props) => {
    const { hat } = props;

    return (<div className="shoe" key={hat.id}>
        <p>Manufacturer: {hat.fabric}</p>
        <p>Model: {hat.style_name}</p>
        
        <Link to= {`/shoes/edit/${hat.id}`}><button className="btn btn-primary m-1">Update Shoe</button></Link>
        <button onClick={() => props.handleDelete(hat.id)} className="btn btn-primary m-1">Delete Shoe</button>
    </div>);
}

export default Hat;