import React, { Component } from 'react'
// import Accordion from './Accordion';
import { Link } from 'react-router-dom';
import Hat from './Hat';


export default class Hats extends Component {
    state = {
        hats: []
    }

    async componentDidMount(){
        const request = await fetch("http://localhost:8090/api/hats/");
        const data = await request.json();
        
        this.setState({
            hats: data.hats,
        })
    }

    render() {
        return (
            <div className='grid text-center mt-5'>
                <div className="container row">
                    <h1 className='col-10' >Here are hats:</h1>
                    <Link to="/hats/add" className='col-2 btn btn-success'>Add Hat</Link>
                </div>
                <>
                    { this.state.hats.map(hat => <Hat key={hat.id} hat={hat} handleDelete={this.handleDelete}/>) }
                </>
            </div>
        )
    }
}
