import { Link } from 'react-router-dom';

const Shoe = (props) => {
    const { shoe } = props;
    console.log(shoe);
    return (<div className="shoe" key={shoe.id}>
        <p>Manufacturer: {shoe.manufacturer}</p>
        <p>Model: {shoe.model_name}</p>
        <p>Color: {shoe.color}</p>
        <img src={shoe.pic_url} alt={shoe.pic_url}/>
        <button onClick={() => props.handleDelete(shoe.id)} className="btn btn-primary m-1">Delete Shoe</button>
    </div>);
}

export default Shoe;