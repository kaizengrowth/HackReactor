import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Shoe from './Shoe';

export default class Shoes extends Component {
    state = {
        shoes: []
    };
    
    async componentDidMount(){
        const request = await fetch("http://localhost:8080/api/shoes/");
        const data = await request.json();
        this.setState({
            shoes: data.shoes,
        })
    }

    handleDelete = async (id) => {
        const request = await fetch(`http://localhost:8080/api/shoes/${id}`, { method: "DELETE"});
        const data = await request.json();

        this.setState({
            shoes: this.state.shoes.filter(shoe => shoe.id !== id)
        })
    }

    render() {
        return (
            <div className='grid text-center'>
                <h1>Displaying Shoes:</h1>
                <Link to="/shoes/add" className='col-2 btn btn-success'>Add Shoe</Link>
                <>
                    { this.state.shoes.map(shoe => <Shoe key={shoe.id} shoe={shoe} handleDelete={this.handleDelete}/>) }
                </>
            </div>
        )
    }
}


