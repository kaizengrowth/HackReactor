import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MainPage from './MainPage';
import Nav from './Nav';

import Shoes from './shoes/Shoes'
import ShoeForm from './shoes/ShoeForm';
import UpdateShoe from './shoes/UpdateShoe'

import Hats from './hats/Hats';
import HatForm from './hats/HatForm';

import UpdateHat from './hats/UpdateHat';

import "./index.css";

function App() {
  return (
    <BrowserRouter>
      <Nav />
      <div className="container w-75">
        <Routes>

          <Route path="/" element={<MainPage />} />

          <Route path="hats" element={<Hats />} />
          <Route path="hats/add" element={<HatForm />} />
          <Route path='hats/edit/:id' element={<UpdateHat />} />

          <Route path="shoes" element={<Shoes />} />
          <Route path="shoes/add" element={<ShoeForm />} />
          <Route path="shoes/edit/:id" element={<UpdateShoe />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;


