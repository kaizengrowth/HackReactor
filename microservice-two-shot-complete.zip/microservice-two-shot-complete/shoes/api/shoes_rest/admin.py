from django.contrib import admin
from .models import BinVO, Shoe

# Register your models here.
admin.site.register(Shoe)
admin.site.register(BinVO)
