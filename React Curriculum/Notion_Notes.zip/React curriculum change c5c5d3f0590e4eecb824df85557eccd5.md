# React curriculum change

Tags: React

[Learning Schedule](https://www.notion.so/Skills-Checklist-9f570c6e917b44cda66ef166beab6094)

**CONTENTS**
[Day 1](React%20curriculum%20change%20c5c5d3f0590e4eecb824df85557eccd5.md)

[Day 2](React%20curriculum%20change%20c5c5d3f0590e4eecb824df85557eccd5.md)

[Day 3](React%20curriculum%20change%20c5c5d3f0590e4eecb824df85557eccd5.md)

**Pre-Work:**

React [Week 9, Day 5]

1)  Exploration — [https://gitlab.com/gsei19/nineteen-week/week-09-javascript/-/blob/main/src/05-react/01-learning-react.md](https://gitlab.com/gsei19/nineteen-week/week-09-javascript/-/blob/main/src/05-react/01-learning-react.md)

Only change the link to the Beta docs, and specify where they need to learn up to (Bart)

2) Students are going through a project with Malik with React components 

—> Spend time going through entire project.

# **Day 1:**

## **Morning:**

**TOPICS:** 

React Project Structure

React With Docker

Component

Props

De-structuring

useState	

**Lecture repo:** 

[](https://gitlab.com/-/ide/project/gsei19/nineteen-week/week-09-javascript/edit/main/-/src/05-react/50-a-react-ui.md)

Changes that need to be made:

1)  Don’t add anything to the App.js component

2)  React Hooks & Functional components

— useState

2) Teach basic JSX

3) Ask them to code along

4) Ask them to do a quick exercise, and then share it with everyone.

===== 

Ask students to do the setup along with me. 

1. Have students show me their emoji.
2. Create a Dockerfile
3. Make sure students have stopped all other Docker containers
4. Have them run the docker command to create the React app
5. During long create-react-app installation pause, go over more slides, and add pets!
6. Have them open up the application in [localhost:3000](http://localhost:3000) 
7. Have everyone show me their emoji
8. Add h1 tag with “Hello, the Book of Face [add emoji] 😳” in the App component —> “YAY!” 
9. Show them the file structure, index.html, index.js and app.js
    1. Index.js —> no report vitals
10. Inside of App.js:
    1. Change the banner image:
        
        ![Untitled](React%20curriculum%20change%20c5c5d3f0590e4eecb824df85557eccd5/Untitled.png)
        
    2. Go to App.css and change some attributes:
        1. Width, background & font color
        2. Remote the header component out of <header> in App.js
    3. Create a component called “Nav.js” and a component called “Main.js”
    4. Move the <h1> to Nav.js, and change the text to <h3>
    5. Inside of “Nav.js”, create a component called “MenuItem.js” with the text “Item 1”
    6. Pass the whole numbers array from Nav.js to MenuItem.js as props
        1. Show how to change the MenuItems component to take in props
        2. First, get the MenuItems component to print all the numbers in the array
        3. Then, get the MenuItems component to print one number (number[0])
        4. Then, manually get three MenuItems components to print three numbers (number[1], number[2])
        5. Then, show how to map through the numbers array and print 8 components, passing each number as a prop
            
            ```jsx
            { numbers.map(number => <MenuItem number={number} />) }
            ```
            
        6. **Get students to “git commit , git push”**
        
          END OF CHECKPOINT 1
        
    7. Pass some link names from Nav.js to MenuItem.js
        1. home, search, global, social net, invite, faq, logout
    8. Render link names as Navbar items
        1. Style: white, blue background
        2. Say: Afternoon, will show how to style with Bootstrap for nested Navbar items
        
        END OF CHECKPOINT 2
        
    
     j.  Now create Main.js and create subcomponents called Post.js
    
    k.  Pass in a JSON object into Post.js: { name, status, time, likes } 
    
    i.   Destructure this prop object in the child component
    
    j.   Display all the posts from the JSON object in Main.js by passing into multiple Post components
    
         END OF CHECKPOINT 3
    
     
    
    k.   Inside of the Post.js component, create a setState method for adding likes
    
    l.    Create a button for likes
    
    m.  Create a handleLikes method in the Post component that increments the number of likes
    
    END OF CHECKPOINT 4
    

LIFTING UP STATE TO AN ARRAY OF OBJECTS:
[https://upmostly.com/tutorials/how-to-update-state-onchange-in-an-array-of-objects-using-react-hooks](https://upmostly.com/tutorials/how-to-update-state-onchange-in-an-array-of-objects-using-react-hooks)

	

## **Afternoon:**

Quiz
- Review:  JSX, state, props, component hierarchy, prop drilling, array destructuring

**state is fully private to the component declaring it.**
 The parent component can’t change it.

Handing down event as a prop

Event propogation 
  “bubbling” up the tree
 

Adding external libraries:

Add bootstrap

Add time library

# Day 2:

## **Morning:**

fetch

promise async/await

useEffect(()=>{}, [])

Forms	

## **Afternoon:**

Passing State through Props

List views

Working with a backend	

# Day 3:

## **Morning:**

Mockup -> Component

React Router		

## **Afternoon:**

React Router Hooks

Basic Styling